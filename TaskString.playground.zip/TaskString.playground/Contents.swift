import UIKit

var string = "Hello"
var reversedString = ""
for str in string {
    reversedString.insert(str, at: reversedString.startIndex)
}
print(reversedString)
